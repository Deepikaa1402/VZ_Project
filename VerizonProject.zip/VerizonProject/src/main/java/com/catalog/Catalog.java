package com.catalog;

import java.util.ArrayList;

import javax.persistence.Entity;
@Entity
public class Catalog 
	{
		private int CatalogId;
		private String name;
	  Catalog(){}
	  public int getCatalogId()
	  {
		  return this.CatalogId;
	  }
	  public String getName()
	  {
		  return this.name;
	  }
	  Catalog(String name){
		  this.name=name;
	  }
	  Catalog(String name,int id){
		  this.name=name;
		  this.CatalogId=id;
	  }
	  public void test()
	  {
		  System.out.println("Test Method");
	  }
	  ArrayList<String>getCatalogList(){
	  ArrayList<String>data=new ArrayList<String>();
	  {
	   data.add("clothes");
	   data.add("shoes");
	   return data;
	     }
	  }
	}


