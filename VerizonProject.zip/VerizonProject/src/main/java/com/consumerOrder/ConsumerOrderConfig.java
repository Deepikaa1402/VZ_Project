package com.consumerOrder;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages="BeanAnnotation")
public class ConsumerOrderConfig {
@Bean
public ConsumerOrderConfig orderBean()
{
	return new ConsumerOrderConfig();
}
}
