package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SeleniumDefinition {
	WebDriver driver;
	@Given("User is on the MakeMyTrip home page")
	public void user_is_on_the_make_my_trip_home_page() throws InterruptedException{
	System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\VerizonTesting\\VerizonSelenium\\chromedriver.exe");
	driver=new ChromeDriver();
	Thread.sleep(3000);
    driver.navigate().to("https://www.makemytrip.com/");
	Thread.sleep(3000);
    driver.manage().window().maximize();
    Thread.sleep(3000);
    JavascriptExecutor js=(JavascriptExecutor)driver;
	 js.executeScript("document.elementFromPoint(0,0).click()");
	}
	@When("user enters mobile number {string}")
	public void user_enters_mobile_number(String string) throws InterruptedException {
		driver.findElement(By.id("username")).sendKeys(string);
		 Thread.sleep(3000);
	}
	@When("continue is clicked")
	public void continue_is_clicked() throws InterruptedException {
		driver.findElement(By.xpath("//*[@data-cy='continueBtn']")).click();
		Thread.sleep(3000);
	}
	@Then("OTP is sent {string}")
	public void otp_is_sent(String string) throws InterruptedException {
		 driver.findElement(By.xpath("//*[@data-cy='enterOtp']")).sendKeys(string);
		 Thread.sleep(3000);
	}
	@Then("OTP is validated")
	public void otp_is_validated() throws InterruptedException {
		 driver.findElement(By.xpath("//*[@data-cy='verifyAndCreate']")).click();
		 Thread.sleep(3000);
		 JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("document.elementFromPoint(0,0).click()");	
		 }

}
